#!/bin/bash
set -v

chmod go-rw /apps/userenv/modules/applications/bar/1.0
chmod go-rwx /apps/userenv/modules/applications/foo
