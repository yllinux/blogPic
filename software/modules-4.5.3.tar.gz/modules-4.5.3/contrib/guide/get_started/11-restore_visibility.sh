#!/bin/bash
set -v

chmod go+r /apps/userenv/modules/applications/bar/1.0
chmod go+rx /apps/userenv/modules/applications/foo
