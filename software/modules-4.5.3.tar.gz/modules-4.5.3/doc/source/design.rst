.. _design:

Design notes
============

Developer notes on feature specifications and code design.

..  toctree::
    :maxdepth: 1
    :glob:

    design/*
